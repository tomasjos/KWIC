package com.company;

import com.company.TituloKWIC;
import com.company.driversKWIC;

import java.util.Set;
import java.util.TreeSet;

import static org.junit.jupiter.api.Assertions.*;

class driversKWICTest {

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
    }

    @org.junit.jupiter.api.AfterEach
    void tearDown() {
    }

    @org.junit.jupiter.api.Test
    void main() {

        String[] cad={""};
        driversKWIC.main(cad);



    }
}