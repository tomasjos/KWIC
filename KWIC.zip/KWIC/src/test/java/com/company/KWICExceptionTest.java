package com.company;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class KWICExceptionTest {

    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void getMessage() {
    }

    @Test
    void getLocalizedMessage() {
    }

    @Test
    void getCause() {
    }

    @Test
    void initCause() {
    }

    @Test
    void testToString() {
    }

    @Test
    void printStackTrace() {
    }

    @Test
    void testPrintStackTrace() {
    }

    @Test
    void testPrintStackTrace1() {
    }

    @Test
    void fillInStackTrace() {
    }

    @Test
    void getStackTrace() {
    }

    @Test
    void setStackTrace() {
    }

    @Test
    void getStackTraceDepth() {
    }

    @Test
    void getStackTraceElement() {
    }

    @Test
    void addSuppressed() {
    }

    @Test
    void getSuppressed() {
    }
}