# KWIC
Este ejercicio es una pequeña modificacion sobre el original entregado por el profesor de la asignatura. En este caso se han añadido getters y setters,
así como modificaciones en el codigo -for, concatenaciones de strings- y una clase token de tipo interface que implementara TituloKwic junto con el comparador
Asimismo se han añadido comentarios y pruebas unitarias, y se ha mejorado la gestión de errores incluyendo throw y try catch en todos los casos 
en los que se tenia que añadir un elemento titulokwic a las listas. Se ha incluido una modificacion para que los espacios vacios, las comas y los dos puntos
no sean considerados strings -ahí se ha metido el throw-.

Por otro lado se ha añadido Maven y se ha creado un repositorio git donde se ha subido el proyecto una vez creado.
